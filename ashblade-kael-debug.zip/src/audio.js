// All sound is synthesized with Web Audio: no files, no network.
let sfxRev = null, ac = null, master, sfx, mus, crunch, nbuf, delayIn, delayNode, verbIn, padDuck, bassDuck, kickDist;
const layers = {};
const loops = {};
const last = {};
const rnd = (a, b) => a + Math.random() * (b - a);

function gate(name, gap) {
  if (!ac) return false;
  const t = ac.currentTime;
  if (last[name] !== undefined && t - last[name] < gap) return false;
  last[name] = t;
  return true;
}
function env(node, t, a, peak, d) {
  node.gain.setValueAtTime(0.0001, t);
  node.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), t + a);
  node.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
}
function tone(type, f0, f1, dur, vol, dest = sfx, t = ac.currentTime, a = 0.002) {
  const o = ac.createOscillator();
  o.type = type;
  o.frequency.setValueAtTime(f0, t);
  if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t + a + dur);
  const e = ac.createGain();
  env(e, t, a, vol, dur);
  o.connect(e); e.connect(dest);
  o.start(t); o.stop(t + a + dur + 0.03);
}
function hiss(dur, vol, type, f0, f1, q = 1, dest = sfx, t = ac.currentTime, a = 0.002) {
  const s = ac.createBufferSource();
  s.buffer = nbuf;
  const f = ac.createBiquadFilter();
  f.type = type; f.Q.value = q;
  f.frequency.setValueAtTime(f0, t);
  if (f1 && f1 !== f0) f.frequency.exponentialRampToValueAtTime(f1, t + a + dur);
  const e = ac.createGain();
  env(e, t, a, vol, dur);
  s.connect(f); f.connect(e); e.connect(dest);
  s.start(t, Math.random() * 1.2); s.stop(t + a + dur + 0.03);
}
const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);

// ---------- soundtrack ----------
// Lead lines are offsets from D4 (MIDI 62), '.' is a rest. Bass is offset from each bar's root.
const bars = (s) => s.split('|').map((b) => b.trim().split(/\s+/).map((t) => (t === '.' ? null : +t)));
const same = (s) => bars([s, s, s, s].join('|'));
const DM = [0, 3, 7], MA = [0, 4, 7];
const TRACKS = {
  'ASHEN HYMN': {
    choir: true, bpm: 80, prog: [[38, DM], [34, MA], [31, DM], [33, MA]],
    kick: 'x.......x.......', snare: '................', hat: '..........x.....',
    bass: bars('0 . . . . . . . . . . . . . . .|0 . . . . . . . . . . . . . . .|0 . . . . . . . . . . . . . . .|0 . . . . . . . . . . . 7 . . .'),
    bassLen: 14, bassCut: 500,
    lead: bars('7 . . . 5 . 3 . 2 . . . 0 . . .|8 . . . 7 . 5 . 3 . . . 5 . . .|5 . . . 3 . 2 . 0 . . . -2 . . .|-1 . . . 2 . . . 7 . . . . . . .'),
    leadType: 'triangle', leadVol: 0.09, leadOct: 12, bell: true,
  },
  // ----- battle music -----
  'PIT DIRGE': {
    harm: true, stab: true, wobble: true, hey: [[], [12], [], [12, 14]], bpm: 150, prog: [[38, DM], [34, MA], [36, MA], [33, MA]],
    kick: 'x...x...x...x...', snare: '....x.......x...', clap: '....x.......x...', hat: '..x...x...x...x.',
    bass: same('. . 0 12 . . 0 12 . . 0 12 . . 0 12'), bassLen: 1.6, bassCut: 1800,
    lead: bars('12 . 10 . 12 . 15 . 14 . 12 . 10 . 7 .|8 . . 10 12 . . . 10 . 8 . 7 . . .|7 . 10 . 12 . 14 . 15 . 14 . 12 . 10 .|13 . . . 16 . . . 19 . . . 13 . 12 .'),
    leadType: 'square', leadVol: 0.05, leadOct: 0, arp: [0, 1, 2, 3, 2, 1, 0, 2, 1, 3, 2, 0, 3, 2, 1, 2],
  },
  BLOODRUSH: {
    wobble: true, harm: true, hey: [[], [], [], [12, 14]], bpm: 172, prog: [[38, DM], [38, DM], [34, MA], [36, MA]],
    kick: 'x.........x.....', snare: '....x.......x...', hat: 'x.xxx.xxx.xxx.xx', tom: '..............xx',
    bass: same('0 . . . . . . . . . 0 . 3 . . .'), bassLen: 5, bassCut: 900, dist: true,
    lead: bars('12 . . 12 . . 15 . . . 12 . 10 . . .|12 . . 12 . . 17 . . . 15 . 12 . . .|10 . . 10 . . 14 . . . 12 . 10 . 8 .|12 . . 12 . . 14 . 15 . 17 . 19 . . .'),
    leadType: 'sawtooth', leadVol: 0.04, leadOct: 0, supersaw: true, arp: [0, 2, 3, 2, 0, 2, 3, 2, 0, 2, 3, 2, 0, 2, 3, 2],
  },
  'NEON PULSE': {
    harm: true, stab: true, hey: [[], [], [], [12]], bpm: 140, prog: [[38, DM], [34, MA], [41, MA], [36, MA]],
    kick: 'x...x...x...x...', snare: '....x.......x...', clap: '....x.......x...', hat: '..x...x...x...x.',
    bass: same('. . 12 . . . 12 . . . 12 . . . 12 0'), bassLen: 1.8, bassCut: 1700,
    lead: bars('7 . . 10 . . 12 . 14 . . 12 . 10 . .|5 . . 8 . . 10 . 12 . . 10 . 8 . .|3 . . 7 . . 10 . 15 . . 14 . 12 . .|7 . . . 5 . . . 2 . . . 0 . . .'),
    leadType: 'sawtooth', leadVol: 0.045, leadOct: 0, supersaw: true, arp: [0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3],
  },
  // ----- one theme per boss -----
  WARDEN: {
    stab: true, wobble: true, harm: true, hey: [[4, 12], [4, 12], [4, 12], [4, 12, 14]], bpm: 162, prog: [[38, DM], [36, MA], [34, MA], [33, MA]],
    kick: 'x...x...x...x...', snare: '....x.......x..x', hat: 'xxxxxxxxxxxxxxxx', tom: '............xxxx',
    bass: bars('0 . 12 . 0 . 12 . 0 . 12 . 0 . 12 .|0 . 12 . 0 . 12 . 0 . 12 . 0 . 12 .|0 . 12 . 0 . 12 . 0 . 12 . 0 . 12 .|0 . 12 . 0 . 12 . 0 12 0 12 0 . 12 .'),
    bassLen: 1.5, bassCut: 1600,
    lead: bars('12 . . 12 15 . 12 . 17 . 15 . 12 . 10 .|10 . . 10 14 . 10 . 15 . 14 . 10 . 7 .|8 . . 8 12 . 8 . 15 . 12 . 8 . 10 .|13 . 12 . 13 . 16 . 19 . 16 . 13 . 12 .'),
    leadType: 'sawtooth', leadVol: 0.045, leadOct: 0, supersaw: true, arp: [0, 2, 1, 3, 0, 2, 1, 3, 0, 2, 1, 3, 0, 2, 1, 3],
  },
  BROOD: {
    wobble: true, harm: true, bpm: 166, prog: [[38, DM], [39, MA], [38, DM], [36, DM]],
    kick: 'x..x..x...x..x..', snare: '....x.......x..x', hat: 'xxxxxxxxxxxxxxxx', tom: '..x.....x.x.....',
    bass: same('0 . 1 0 . 1 0 . 3 . 1 0 . 1 . 0'), bassLen: 0.8, bassCut: 1200, dist: true,
    lead: bars('12 13 12 13 15 . 13 . 12 13 12 13 10 . 8 .|13 15 13 15 17 . 15 . 13 15 13 15 12 . 10 .|12 13 12 13 15 . 13 . 12 13 12 13 18 . 17 .|10 12 10 12 13 . 12 . 10 . 8 . 7 . 6 .'),
    leadType: 'square', leadVol: 0.04, leadOct: 0,
  },
  COLOSSUS: {
    stab: true, wobble: true, harm: true, hey: [[], [12], [], [12]], bpm: 142, prog: [[38, DM], [38, DM], [41, MA], [39, MA]],
    kick: 'x..x..x.x..x..x.', snare: '....x.......x...', clap: '....x.......x...', hat: '..x...x...x...x.', metal: true, tom: '.......x.......x',
    bass: same('0 . . 0 . . 0 . 0 . . 0 . 0 0 .'), bassLen: 1.2, bassCut: 700, dist: true,
    lead: bars('0 . . 3 . . 5 . 6 . 5 . 3 . . .|0 . . 3 . . 5 . 8 . 6 . 5 . . .|3 . . 7 . . 8 . 10 . 8 . 7 . . .|1 . . 3 . . 1 . 0 . . . -2 . . .'),
    leadType: 'square', leadVol: 0.06, leadOct: 0, arp: [0, 0, 3, 0, 0, 3, 0, 2, 0, 0, 3, 0, 0, 3, 2, 1],
  },
  KINGFALL: {
    stab: true, choir: true, harm: true, hey: [[], [], [], [12, 13, 14]], bpm: 160, prog: [[38, DM], [39, MA], [38, DM], [37, [0, 3, 6]]],
    kick: 'x..x..x...x..x..', snare: '....x.......x.xx', hat: 'x.x.x.x.x.x.x.x.', tom: 'x.......x...x.x.', clap: '............x...',
    bass: bars('0 0 . 0 0 . 0 . 0 0 . 0 12 . 0 .|0 0 . 0 0 . 0 . 0 0 . 0 12 . 0 .|0 0 . 0 0 . 0 . 0 0 . 0 12 . 0 .|0 0 . 0 0 . 0 . 0 0 . 0 12 . 1 .'),
    bassLen: 1.4, bassCut: 900, dist: true,
    lead: bars('12 . . . 13 . . . 12 . 10 . 8 . 7 .|13 . . . 15 . . . 13 . 12 . 10 . 8 .|12 . 13 . 12 . 10 . 7 . 8 . 10 . 12 .|11 . . . 10 . . . 8 . 7 . 6 . 7 .'),
    leadType: 'sawtooth', leadVol: 0.05, leadOct: 0, bell: true, supersaw: true, arp: [0, 1, 2, 1, 0, 1, 2, 3, 0, 1, 2, 1, 0, 2, 3, 2],
  },
};
Object.assign(TRACKS, {
  VOID: {
    wobble: true, choir: true, harm: true, bpm: 150, prog: [[38, DM], [39, MA], [41, MA], [39, MA]],
    kick: 'x..x..x.x.....x.', snare: '....x.......x...', hat: 'x.x.x.x.x.x.x.x.', tom: '..............xx',
    bass: same('0 . . 0 . 0 . . 0 . . 0 . 1 . 0'), bassLen: 1.3, bassCut: 900, dist: true,
    lead: bars('0 . . 1 . . 3 . 1 . . 0 . -2 . .|0 . . 1 . . 5 . 3 . . 1 . 0 . .|3 . . 5 . . 6 . 5 . . 3 . 1 . .|1 . . 0 . . -2 . 0 . . . . . . .'),
    leadType: 'sawtooth', leadVol: 0.045, leadOct: 12, supersaw: true,
  },
  TEMPEST: {
    stab: true, wobble: true, harm: true, hey: [[], [], [], [12, 14]], bpm: 174, prog: [[38, DM], [36, MA], [34, MA], [36, MA]],
    kick: 'x.........x.....', snare: '....x.......x...', hat: 'xxxxxxxxxxxxxxxx', clap: '............x...',
    bass: same('0 . . . . . 0 . . . 0 . 12 . . .'), bassLen: 4, bassCut: 1000, dist: true,
    lead: bars('19 . 17 . 15 . 14 . 12 . 14 . 15 . 17 .|17 . 15 . 14 . 12 . 10 . 12 . 14 . 15 .|15 . 14 . 12 . 10 . 8 . 10 . 12 . 14 .|13 . . . 16 . . . 19 . . . 22 . . .'),
    leadType: 'square', leadVol: 0.04, leadOct: 0, arp: [0, 1, 2, 3, 2, 1, 0, 1, 2, 3, 2, 1, 0, 1, 2, 3],
  },
  ECLIPSE: {
    stab: true, choir: true, harm: true, bell: true, hey: [[], [12], [], [12, 13, 14]], bpm: 160, prog: [[38, DM], [34, MA], [36, MA], [37, [0, 3, 6]]],
    kick: 'x...x...x...x...', snare: '....x.......x.x.', clap: '....x.......x...', hat: 'x.xxx.xxx.xxx.xx', tom: 'x...x...x..xxxxx',
    bass: same('0 0 12 0 0 12 0 0 0 0 12 0 0 12 0 12'), bassLen: 0.9, bassCut: 1200, dist: true,
    lead: bars('12 . . 15 . . 19 . 17 . . 15 . 14 . .|10 . . 14 . . 17 . 15 . . 14 . 12 . .|12 . . 16 . . 19 . 21 . . 19 . 16 . .|13 . . . 12 . . . 10 . . . 9 . . .'),
    leadType: 'sawtooth', leadVol: 0.045, leadOct: 0, supersaw: true, arp: [0, 2, 1, 3, 0, 2, 1, 3, 0, 2, 1, 3, 0, 2, 1, 3],
  },
});
// the default battle music: hard-kick EDM at 150 bpm
TRACKS.HYPERDRIVE = {
  hard: true, stab: true, harm: true, hey: [[], [12], [], [4, 12, 14]], bpm: 150,
  prog: [[38, DM], [34, MA], [41, MA], [36, MA]],
  kick: 'x...x...x...x...', snare: '....x.......x...', clap: '....x.......x...', hat: '..x...x...x...x.', tom: '..............xx',
  bass: same('. . 0 12 . . 0 12 . . 0 12 . . 0 12'), bassLen: 1.2, bassCut: 2000, dist: true,
  lead: bars('12 . 12 . 15 . 12 . 17 . 15 . 12 . 10 .|10 . 10 . 14 . 10 . 15 . 14 . 10 . 8 .|15 . 15 . 19 . 15 . 20 . 19 . 15 . 12 .|14 . 14 . 17 . 14 . 19 . 17 . 14 . 12 .'),
  leadType: 'sawtooth', leadVol: 0.045, leadOct: 0, supersaw: true, arp: [0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3],
};
// the Mirror plays the battle theme backwards, slower and sung
TRACKS.REFLECTION = { ...TRACKS['PIT DIRGE'], bpm: 146, leadType: 'triangle', leadOct: 12, bell: true, choir: true, hey: null, lead: TRACKS['PIT DIRGE'].lead.map((b) => [...b].reverse()) };

// what plays in each moment when the soundtrack is AUTO, and how loud each layer is
const SCENES = {
  title: { track: 'HYPERDRIVE', pad: 0.7, bass: 0.8, drums: 0.85, arp: 0.6, lead: 1 },
  calm: { track: 'HYPERDRIVE', pad: 1, bass: 0.5, drums: 0.35, arp: 0.5, lead: 0.6 },
  fight: { track: 'COMBAT', pad: 0.5, bass: 1, drums: 1, arp: 0.7, lead: 0.75 },
  hot: { track: 'COMBAT', pad: 0.6, bass: 1, drums: 1, arp: 1, lead: 1 },
  boss_warden: { track: 'WARDEN', pad: 0.5, bass: 1, drums: 1, arp: 0.8, lead: 1 },
  boss_brood: { track: 'BROOD', pad: 0.4, bass: 1, drums: 1, arp: 0, lead: 1 },
  boss_colossus: { track: 'COLOSSUS', pad: 0.6, bass: 1, drums: 1, arp: 0.6, lead: 1 },
  boss_king: { track: 'KINGFALL', pad: 1, bass: 1, drums: 1, arp: 0.7, lead: 1 },
  boss_wyrm: { track: 'VOID', pad: 1, bass: 1, drums: 1, arp: 0, lead: 1 },
  boss_herald: { track: 'TEMPEST', pad: 0.5, bass: 1, drums: 1, arp: 0.9, lead: 1 },
  boss_mirror: { track: 'REFLECTION', pad: 0.8, bass: 1, drums: 1, arp: 0.6, lead: 1 },
  boss_eclipse: { track: 'ECLIPSE', pad: 1, bass: 1, drums: 1, arp: 0.8, lead: 1 },
  boss_clock: { track: 'TEMPEST', pad: 0.8, bass: 1, drums: 1, arp: 1, lead: 0.8 },
  // the final boss plays the title theme at full force: he wrote it
  boss_dev: { track: 'HYPERDRIVE', pad: 0.6, bass: 1, drums: 1, arp: 1, lead: 1 },
  dead: { track: null, pad: 0.6, bass: 0, drums: 0, arp: 0, lead: 0 },
  // the opening plays its own score (A.intro*), so the soundtrack waits
  intro: { track: null, pad: 0, bass: 0, drums: 0, arp: 0, lead: 0 },
};
let choice = 'AUTO', combat = 'PIT DIRGE', scene = 'title', cur = TRACKS['ASHEN HYMN'], pending = null;
let step = 0, nextT = 0, mcr = null;
const S16 = () => 60 / cur.bpm / 4;

function kick(t) {
  tone('sine', 160, 42, 0.22, 1, layers.drums, t); tone('sine', 60, 38, 0.3, 0.5, layers.drums, t);
  if (cur.hard) { tone('sine', 230, 48, 0.24, 1, kickDist, t); hiss(0.02, 0.4, 'bandpass', 2500, 1500, 2, layers.drums, t); }
  hiss(0.012, 0.3, 'highpass', 3000, 3000, 1, layers.drums, t);
  for (const d of [padDuck, bassDuck]) { d.gain.cancelScheduledValues(t); d.gain.setValueAtTime(d === padDuck ? 0.35 : 0.55, t); d.gain.linearRampToValueAtTime(1, t + 0.2); }
}
function crash(t) { hiss(1.6, 0.12, 'highpass', 5000, 3500, 0.7, layers.drums, t); hiss(1.2, 0.06, 'highpass', 5000, 3500, 0.7, verbIn, t); }
// a gang shout: noise through two vowel formants, a few voices slightly apart
function hey(t) {
  for (let v = 0; v < 4; v++) {
    const at = t + v * 0.008, s = ac.createBufferSource(), f1 = ac.createBiquadFilter(), f2 = ac.createBiquadFilter(), g = ac.createGain(), o = ac.createOscillator(), og = ac.createGain();
    s.buffer = nbuf; f1.type = 'bandpass'; f1.frequency.value = 650 + v * 40; f1.Q.value = 6; f2.type = 'bandpass'; f2.frequency.value = 1150 + v * 60; f2.Q.value = 6;
    env(g, at, 0.01, 0.5, 0.14);
    o.type = 'sawtooth'; o.frequency.setValueAtTime(170 + v * 23, at); o.frequency.exponentialRampToValueAtTime(130 + v * 18, at + 0.15);
    env(og, at, 0.01, 0.12, 0.13);
    s.connect(f1); s.connect(f2); f1.connect(g); f2.connect(g); o.connect(f1); o.connect(f2); o.connect(og); og.connect(f1);
    g.connect(layers.drums); g.connect(verbIn);
    s.start(at, Math.random()); s.stop(at + 0.2); o.start(at); o.stop(at + 0.2);
  }
}
// ---------- the opening's score ----------
// A crowd, a choir and war drums, all synthesized. Everything goes to its own bus that feeds the music
// volume and the hall reverb, so it sounds like an arena.
let introBus = null;
function ibus() {
  if (!introBus) { introBus = ac.createGain(); introBus.gain.value = 0.9; introBus.connect(mus); const r = ac.createGain(); r.gain.value = 0.9; introBus.connect(r); r.connect(verbIn); }
  return introBus;
}
// a crowd: many voices of filtered noise on 'ah' and 'oh' formants, each swelling and wavering on its own
function crowd(t, dur, vol, swell = 0.5) {
  const out = ibus();
  for (let v = 0; v < 12; v++) {
    const s = ac.createBufferSource(), f1 = ac.createBiquadFilter(), f2 = ac.createBiquadFilter(), g = ac.createGain(), pan = ac.createStereoPanner();
    const lfo = ac.createOscillator(), lg = ac.createGain();
    s.buffer = nbuf; s.loop = true;
    f1.type = 'bandpass'; f1.frequency.value = rnd(450, 800); f1.Q.value = rnd(3, 6);
    f2.type = 'bandpass'; f2.frequency.value = rnd(1000, 1600); f2.Q.value = rnd(3, 6);
    const peak = vol * rnd(0.6, 1.1), at = t + rnd(0, 0.15);
    g.gain.setValueAtTime(0.0001, at); g.gain.exponentialRampToValueAtTime(peak, at + swell); g.gain.setValueAtTime(peak, at + dur * 0.6); g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
    lfo.frequency.value = rnd(1.5, 5); lg.gain.value = peak * 0.5; lfo.connect(lg); lg.connect(g.gain);
    pan.pan.value = rnd(-0.9, 0.9);
    s.connect(f1); s.connect(f2); f1.connect(g); f2.connect(g); g.connect(pan); pan.connect(out);
    s.start(at, Math.random() * 2); s.stop(at + dur + 0.1); lfo.start(at); lfo.stop(at + dur + 0.1);
  }
}
// whistles from the crowd
function whistles(t, n) { for (let i = 0; i < n; i++) { const at = t + rnd(0, 0.8), f = rnd(1800, 2600); tone('sine', f, f * rnd(1.1, 1.4), rnd(0.25, 0.5), 0.05, ibus(), at, 0.03); } }
// a choir chord: voices on a vowel, slowly swelling
function choirChord(t, dur, notes, vol = 0.06) {
  for (const n of notes) for (const det of [-9, 9]) {
    const o = ac.createOscillator(), f1 = ac.createBiquadFilter(), f2 = ac.createBiquadFilter(), e = ac.createGain(), lfo = ac.createOscillator(), lg = ac.createGain();
    o.type = 'sawtooth'; o.frequency.value = mtof(n); o.detune.value = det;
    lfo.frequency.value = 5.5; lg.gain.value = 5; lfo.connect(lg); lg.connect(o.detune);
    f1.type = 'bandpass'; f1.frequency.value = 800; f1.Q.value = 4; f2.type = 'bandpass'; f2.frequency.value = 1150; f2.Q.value = 5;
    e.gain.setValueAtTime(0.0001, t); e.gain.exponentialRampToValueAtTime(vol, t + Math.min(1.2, dur * 0.4)); e.gain.setValueAtTime(vol, t + dur * 0.75); e.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(f1); o.connect(f2); f1.connect(e); f2.connect(e); e.connect(ibus());
    o.start(t); o.stop(t + dur + 0.05); lfo.start(t); lfo.stop(t + dur + 0.05);
  }
}
// a brass stab: detuned saws through a filter that opens and closes fast
function brass(t, notes, dur = 0.7, vol = 0.07) {
  for (const n of notes) for (const det of [-12, 0, 12]) {
    const o = ac.createOscillator(), f = ac.createBiquadFilter(), e = ac.createGain();
    o.type = 'sawtooth'; o.frequency.value = mtof(n); o.detune.value = det;
    f.type = 'lowpass'; f.Q.value = 2; f.frequency.setValueAtTime(400, t); f.frequency.exponentialRampToValueAtTime(3200, t + 0.06); f.frequency.exponentialRampToValueAtTime(700, t + dur);
    env(e, t, 0.02, vol, dur);
    o.connect(f); f.connect(e); e.connect(ibus());
    o.start(t); o.stop(t + dur + 0.1);
  }
}
// a war drum: a deep body and a slap of skin
function taiko(t, vol = 1, pitch = 1) {
  tone('sine', 120 * pitch, 42 * pitch, 0.55, 0.9 * vol, ibus(), t); tone('triangle', 240 * pitch, 80 * pitch, 0.15, 0.35 * vol, ibus(), t);
  hiss(0.08, 0.4 * vol, 'lowpass', 1600, 300, 1, ibus(), t);
}
function cymbal(t, dur = 2.2, vol = 0.14) { hiss(dur, vol, 'highpass', 6000, 3800, 0.7, ibus(), t); hiss(dur * 0.8, vol * 0.6, 'bandpass', 9000, 7000, 2, ibus(), t); }
// the gang shout, through the intro bus
function shout(t) {
  for (let v = 0; v < 6; v++) {
    const at = t + v * 0.01, s = ac.createBufferSource(), f1 = ac.createBiquadFilter(), f2 = ac.createBiquadFilter(), g = ac.createGain(), o = ac.createOscillator();
    s.buffer = nbuf; f1.type = 'bandpass'; f1.frequency.value = 650 + v * 35; f1.Q.value = 6; f2.type = 'bandpass'; f2.frequency.value = 1150 + v * 50; f2.Q.value = 6;
    env(g, at, 0.01, 0.55, 0.2);
    o.type = 'sawtooth'; o.frequency.setValueAtTime(160 + v * 21, at); o.frequency.exponentialRampToValueAtTime(120 + v * 16, at + 0.2);
    s.connect(f1); s.connect(f2); o.connect(f1); o.connect(f2); f1.connect(g); f2.connect(g); g.connect(ibus());
    s.start(at, Math.random()); s.stop(at + 0.25); o.start(at); o.stop(at + 0.25);
  }
}
// a braam: a wall of low brass driven through distortion, swelling and dying away
function braam(t, dur = 2.2, vol = 0.18, root = IN_ROOT - 12) {
  for (const iv of [0, 7, 12, 15]) for (const det of [-18, 0, 18]) {
    const o = ac.createOscillator(), f = ac.createBiquadFilter(), e = ac.createGain();
    o.type = 'sawtooth'; o.frequency.value = mtof(root + iv); o.detune.value = det;
    f.type = 'lowpass'; f.Q.value = 3; f.frequency.setValueAtTime(220, t); f.frequency.exponentialRampToValueAtTime(1400, t + 0.25); f.frequency.exponentialRampToValueAtTime(300, t + dur);
    e.gain.setValueAtTime(0.0001, t); e.gain.exponentialRampToValueAtTime(vol / 4, t + 0.08); e.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(f); f.connect(e); e.connect(crunch); e.connect(ibus());
    o.start(t); o.stop(t + dur + 0.05);
  }
}
// a sub drop: the floor falls out
function subDrop(t, vol = 1) { tone('sine', 90, 24, 1.4, 0.9 * vol, ibus(), t); tone('sine', 180, 40, 0.5, 0.4 * vol, crunch, t); hiss(0.6, 0.35 * vol, 'lowpass', 900, 60, 0.7, ibus(), t); }
// steel on steel: a metallic clang with a ringing tail
function clang(t, vol = 1) {
  for (const f of [523, 787, 1243, 1871]) tone('square', f * rnd(0.98, 1.02), f * 0.97, 0.7, 0.025 * vol, ibus(), t);
  hiss(0.06, 0.5 * vol, 'bandpass', 3800, 2500, 2, ibus(), t);
}
// a riser: noise and a tone rushing upward
function introRiser(t, dur, vol = 0.2) {
  hiss(dur, vol, 'bandpass', 300, 6000, 1.5, ibus(), t, dur * 0.9);
  tone('sawtooth', 80, 640, dur, vol * 0.25, ibus(), t, dur * 0.9);
}
// a heartbeat: two soft thumps
function heart(t, vol = 0.6) { tone('sine', 70, 40, 0.18, vol, ibus(), t); tone('sine', 66, 38, 0.2, vol * 0.7, ibus(), t + 0.2); }
// D minor, the game's key
const IN_ROOT = 38;

function snare(t, v = 1) { hiss(0.15, 0.34 * v, 'bandpass', 1900, 1500, 0.8, layers.drums, t); tone('triangle', 200, 150, 0.08, 0.18 * v, layers.drums, t); hiss(0.2, 0.12 * v, 'bandpass', 1900, 1500, 0.8, verbIn, t); }
function clap(t) { for (let i = 0; i < 3; i++) hiss(0.03 + (i === 2 ? 0.08 : 0), 0.3, 'bandpass', 1400, 1200, 1.5, layers.drums, t + i * 0.012); }
function hat(t, open, vel) { if (cur.metal) { hiss(0.06, 0.16, 'bandpass', 7200, 6800, 12, layers.drums, t); tone('square', 3100, 3000, 0.02, 0.02, layers.drums, t); } else hiss(open ? 0.09 : 0.025, 0.09 * vel, 'highpass', 8000, 8000, 1, layers.drums, t); }
function tom(t, i) { const f = 190 - (i % 4) * 25; tone('sine', f, f * 0.45, 0.2, 0.55, layers.drums, t); }
function bassNote(n, t) {
  const o = ac.createOscillator(), f = ac.createBiquadFilter(), e = ac.createGain();
  const len = S16() * cur.bassLen;
  o.type = 'sawtooth'; o.frequency.value = mtof(n);
  f.type = 'lowpass'; f.Q.value = 6;
  f.frequency.setValueAtTime(cur.bassCut, t); f.frequency.exponentialRampToValueAtTime(150, t + Math.min(len, 0.5));
  env(e, t, 0.004, 0.3, len);
  if (cur.wobble) {
    f.frequency.cancelScheduledValues(t); f.frequency.setValueAtTime(700, t); f.Q.value = 10;
    const lfo = ac.createOscillator(), lg = ac.createGain();
    lfo.type = 'triangle'; lfo.frequency.value = (cur.bpm / 60) * 2; lg.gain.value = 650;
    lfo.connect(lg); lg.connect(f.frequency); lfo.start(t); lfo.stop(t + len + 0.05);
  }
  o.connect(f); f.connect(e); e.connect(cur.dist ? mcr : layers.bass);
  o.start(t); o.stop(t + len + 0.05);
  tone('sine', mtof(n - 12), mtof(n - 12), len, 0.28, layers.bass, t, 0.005);
}
function pad(root, ch, t) {
  const dur = S16() * 16;
  for (const iv of ch) for (const det of [-8, 8]) {
    const o = ac.createOscillator(), f = ac.createBiquadFilter(), e = ac.createGain();
    o.type = 'sawtooth'; o.frequency.value = mtof(root + 24 + iv); o.detune.value = det;
    f.type = 'lowpass'; f.frequency.value = 700;
    e.gain.setValueAtTime(0.0001, t);
    e.gain.exponentialRampToValueAtTime(0.026, t + Math.min(0.6, dur / 3));
    e.gain.setValueAtTime(0.026, t + dur * 0.8);
    e.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    const pn = ac.createStereoPanner(); pn.pan.value = det < 0 ? -0.6 : 0.6;
    o.connect(f); f.connect(e); e.connect(pn); pn.connect(layers.pad);
    o.start(t); o.stop(t + dur + 0.05);
  }
  if (cur.choir) for (const iv of ch) {
    const o = ac.createOscillator(), f1 = ac.createBiquadFilter(), f2 = ac.createBiquadFilter(), e = ac.createGain(), lfo = ac.createOscillator(), lg = ac.createGain();
    o.type = 'sawtooth'; o.frequency.value = mtof(root + 36 + iv);
    lfo.frequency.value = 5; lg.gain.value = 4; lfo.connect(lg); lg.connect(o.detune);
    f1.type = 'bandpass'; f1.frequency.value = 750; f1.Q.value = 4; f2.type = 'bandpass'; f2.frequency.value = 1200; f2.Q.value = 5;
    e.gain.setValueAtTime(0.0001, t); e.gain.exponentialRampToValueAtTime(0.05, t + 0.6); e.gain.setValueAtTime(0.05, t + dur * 0.8); e.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(f1); o.connect(f2); f1.connect(e); f2.connect(e); e.connect(layers.pad);
    o.start(t); o.stop(t + dur + 0.05); lfo.start(t); lfo.stop(t + dur + 0.05);
  }
}
function leadNote(n, len, t) {
  const d = Math.max(0.08, S16() * len * 0.95), f = ac.createBiquadFilter(), e = ac.createGain();
  f.type = 'lowpass'; f.frequency.value = cur.leadType === 'sawtooth' ? 2600 : 3200;
  e.gain.setValueAtTime(0.0001, t);
  e.gain.exponentialRampToValueAtTime(cur.leadVol, t + 0.01);
  e.gain.setValueAtTime(cur.leadVol * 0.8, t + d * 0.6);
  e.gain.exponentialRampToValueAtTime(0.0001, t + d + (cur.bell ? 0.4 : 0.05));
  f.connect(e); e.connect(layers.lead); e.connect(delayIn);
  const voices = cur.supersaw ? [[0, -14], [0, 0], [0, 14]] : [[0, 0]];
  if (cur.harm) voices.push([-12, 0], [7, 0]);
  for (const [iv, det] of voices) {
    const o = ac.createOscillator();
    o.type = cur.leadType; o.frequency.value = mtof(n + iv); o.detune.value = det;
    if (iv) { const hg = ac.createGain(); hg.gain.value = iv === 7 ? 0.35 : 0.5; o.connect(hg); hg.connect(f); } else o.connect(f);
    o.start(t); o.stop(t + d + 0.5);
  }
  if (cur.bell) {
    const o2 = ac.createOscillator(), e2 = ac.createGain();
    o2.type = 'sine'; o2.frequency.value = mtof(n + 12);
    env(e2, t, 0.003, cur.leadVol * 0.5, 0.6);
    o2.connect(e2); e2.connect(layers.lead); e2.connect(delayIn);
    o2.start(t); o2.stop(t + 0.7);
  }
}
function arpNote(n, t) {
  const o = ac.createOscillator(), f = ac.createBiquadFilter(), e = ac.createGain();
  o.type = 'square'; o.frequency.value = mtof(n);
  f.type = 'lowpass'; f.frequency.value = 2600;
  env(e, t, 0.003, 0.04, 0.1);
  const pn = ac.createStereoPanner(); pn.pan.value = (step % 2 ? 0.55 : -0.55);
  o.connect(f); f.connect(e); e.connect(pn); pn.connect(layers.arp); e.connect(delayIn);
  o.start(t); o.stop(t + 0.15);
}
// ---------- EDM: offbeat chord stabs, risers, snare rolls and drops ----------
function stab(root, ch, t) {
  const f = ac.createBiquadFilter(), e = ac.createGain();
  f.type = 'lowpass'; f.frequency.setValueAtTime(4200, t); f.frequency.exponentialRampToValueAtTime(900, t + 0.14);
  env(e, t, 0.004, 0.035, 0.13);
  f.connect(e); e.connect(layers.arp); e.connect(verbIn);
  for (const iv of [0, ch[1], ch[2], 12]) for (const det of [-12, 12]) {
    const o = ac.createOscillator(); o.type = 'sawtooth'; o.frequency.value = mtof(root + 36 + iv); o.detune.value = det;
    o.connect(f); o.start(t); o.stop(t + 0.2);
  }
}
function riser(t, dur) {
  const s = ac.createBufferSource(), f = ac.createBiquadFilter(), e = ac.createGain();
  s.buffer = nbuf; s.loop = true;
  f.type = 'bandpass'; f.Q.value = 2; f.frequency.setValueAtTime(400, t); f.frequency.exponentialRampToValueAtTime(9000, t + dur);
  e.gain.setValueAtTime(0.0001, t); e.gain.exponentialRampToValueAtTime(0.22, t + dur);
  s.connect(f); f.connect(e); e.connect(layers.drums); e.connect(verbIn);
  s.start(t); s.stop(t + dur + 0.02);
  tone('sawtooth', 110, 880, dur, 0.04, layers.arp, t, dur * 0.9);
}
function drop(t) {
  tone('sine', 90, 28, 1.1, 0.9, layers.drums, t);
  hiss(0.9, 0.3, 'lowpass', 3000, 100, 0.7, layers.drums, t);
  crash(t); hey(t);
}

function playStep(i, t) {
  const s = i % 16, bar = Math.floor(i / 16) % 4;
  if (s === 0 && pending) { cur = pending; pending = null; if (delayNode) delayNode.delayTime.setValueAtTime(S16() * 3, t); }
  const [root, ch] = cur.prog[bar];
  if (s === 0) pad(root, ch, t);
  const edm = cur.bpm > 100, phrase = Math.floor(i / 16) % 8, build = edm && phrase === 7;
  if (s === 0 && bar === 0 && edm) { if (phrase === 0 && i > 0) drop(t); else crash(t); }
  if (build && s === 0) riser(t, S16() * 16);
  if (build) {
    // snare roll speeding up into the drop, kick drops out for the last half bar
    if (s < 8 ? s % 2 === 0 : true) snare(t, 0.35 + (s / 16) * 0.65);
  }
  if (cur.stab && edm && !build && (s === 2 || s === 6 || s === 10 || s === 14 || (bar === 3 && s === 12))) stab(root, ch, t);
  if (cur.hey && cur.hey[bar] && cur.hey[bar].includes(s)) hey(t);
  const bn = cur.bass[bar][s];
  if (bn !== null && bn !== undefined) bassNote(root + bn, t);
  if (cur.kick[s] === 'x' && !(build && s >= 8)) kick(t);
  if (cur.snare[s] === 'x') snare(t, s % 4 === 0 ? 1 : 0.5);
  if (cur.clap && cur.clap[s] === 'x') clap(t);
  if (cur.hat[s] === 'x') hat(t, s % 8 === 6, s % 2 ? 0.6 : 1);
  if (cur.tom && cur.tom[s] === 'x' && (bar === 3 || !cur.tom.endsWith('xxxx'))) tom(t, s);
  const ln = cur.lead[bar][s];
  if (ln !== null && ln !== undefined) {
    let len = 1;
    while (len < 4 && s + len < 16 && cur.lead[bar][s + len] === null) len++;
    leadNote(62 + cur.leadOct + ln, len, t);
  }
  if (cur.arp) { const tones = [0, ch[1], ch[2], 12]; arpNote(root + 36 + tones[cur.arp[s]], t); }
}
function schedule() {
  if (!ac || ac.state !== 'running' || choice === 'OFF') return;
  if (nextT < ac.currentTime) nextT = ac.currentTime + 0.05;
  while (nextT < ac.currentTime + 0.12) { playStep(step, nextT); nextT += S16(); step++; }
}
function wantTrack() {
  if (choice !== 'AUTO') return TRACKS[choice] || null;
  const t = SCENES[scene].track;
  return t === 'COMBAT' ? TRACKS[combat] : t ? TRACKS[t] : null;
}
function applyScene() {
  const want = wantTrack();
  if (want && want !== cur) {
    // land the change on the next bar line
    pending = want;
    const s = step % 16;
    if (s !== 0) step += 16 - s;
  }
  if (!ac) return;
  const L = choice === 'AUTO' || scene === 'dead' ? SCENES[scene] : { pad: 0.8, bass: 1, drums: scene === 'title' || scene === 'calm' ? 0.5 : 1, arp: 0.8, lead: 1 };
  for (const k of ['pad', 'bass', 'drums', 'arp', 'lead']) layers[k].gain.setTargetAtTime(L[k], ac.currentTime, 0.5);
}

export const A = {
  get ready() { return !!ac; },
  init(s) {
    if (ac) { if (ac.state === 'suspended') ac.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    ac = new AC();
    const comp = ac.createDynamicsCompressor();
    comp.threshold.value = -16; comp.ratio.value = 5; comp.attack.value = 0.002; comp.release.value = 0.12;
    master = ac.createGain();
    master.connect(comp); comp.connect(ac.destination);
    sfx = ac.createGain(); sfx.connect(master);
    mus = ac.createGain(); mus.connect(master);
    crunch = ac.createWaveShaper();
    const curve = new Float32Array(1024);
    for (let i = 0; i < 1024; i++) { const x = (i / 1023) * 2 - 1; curve[i] = Math.tanh(x * 3.2); }
    crunch.curve = curve;
    const cg = ac.createGain(); cg.gain.value = 0.55;
    crunch.connect(cg); cg.connect(sfx);
    nbuf = ac.createBuffer(1, ac.sampleRate * 2.5, ac.sampleRate);
    const d = nbuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    // a generated hall reverb
    const verb = ac.createConvolver(), ir = ac.createBuffer(2, ac.sampleRate * 2.2, ac.sampleRate);
    for (let c = 0; c < 2; c++) { const ch = ir.getChannelData(c); for (let i = 0; i < ch.length; i++) ch[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / ch.length, 3); }
    verb.buffer = ir;
    // a reverb send for sound effects, so it follows the effects volume, not the music volume
    const sv = ac.createConvolver(); sv.buffer = ir;
    sfxRev = ac.createGain(); sfxRev.gain.value = 0.45; sfxRev.connect(sv); sv.connect(sfx);
    verbIn = ac.createGain(); verbIn.gain.value = 0.32;
    const vlp = ac.createBiquadFilter(); vlp.type = 'lowpass'; vlp.frequency.value = 4000;
    verbIn.connect(vlp); vlp.connect(verb); verb.connect(mus);
    padDuck = ac.createGain(); padDuck.connect(mus);
    bassDuck = ac.createGain(); bassDuck.connect(mus);
    for (const k of ['pad', 'bass', 'drums', 'arp', 'lead']) {
      layers[k] = ac.createGain(); layers[k].gain.value = 0;
      layers[k].connect(k === 'pad' ? padDuck : k === 'bass' ? bassDuck : mus);
      if (k !== 'bass' && k !== 'drums') layers[k].connect(verbIn);
    }
    mcr = ac.createWaveShaper(); mcr.curve = curve;
    kickDist = ac.createWaveShaper();
    const kc = new Float32Array(1024);
    for (let i = 0; i < 1024; i++) { const x = (i / 1023) * 2 - 1; kc[i] = Math.tanh(x * 7); }
    kickDist.curve = kc;
    const kg = ac.createGain(); kg.gain.value = 0.32; kickDist.connect(kg); kg.connect(layers.drums);
    const mg = ac.createGain(); mg.gain.value = 0.45; mcr.connect(mg); mg.connect(layers.bass);
    delayIn = ac.createGain(); delayIn.gain.value = 0.3;
    delayNode = ac.createDelay(2);
    const fb = ac.createGain(), lp = ac.createBiquadFilter();
    delayNode.delayTime.value = S16() * 3; fb.gain.value = 0.35; lp.type = 'lowpass'; lp.frequency.value = 1800;
    delayIn.connect(delayNode); delayNode.connect(lp); lp.connect(fb); fb.connect(delayNode); lp.connect(mus);
    this.settings(s);
    applyScene();
    nextT = ac.currentTime + 0.1;
    setInterval(schedule, 25);
  },
  settings(s) {
    choice = s.track; combat = s.combat;
    if (!ac) return;
    master.gain.setTargetAtTime(s.master * 0.85, ac.currentTime, 0.05);
    mus.gain.setTargetAtTime(choice === 'OFF' ? 0 : s.music * 0.5, ac.currentTime, 0.05);
    sfx.gain.setTargetAtTime(s.sfx, ac.currentTime, 0.05);
    applyScene();
  },
  scene(name) {
    if (!SCENES[name] || name === scene) return;
    scene = name;
    applyScene();
  },
  suspend(on) { if (ac) on ? ac.suspend() : ac.resume(); },

  // continuous sounds: beams, minigun hum, orbital laser
  loop(name, on, kind = 'beam') {
    if (!ac) return;
    const l = loops[name];
    if (on && !l) {
      const o = ac.createOscillator(), o2 = ac.createOscillator(), f = ac.createBiquadFilter(), g = ac.createGain();
      o.type = 'sawtooth'; o2.type = 'square';
      o.frequency.value = kind === 'orbital' ? 55 : kind === 'boss' ? 70 : 180;
      o2.frequency.value = o.frequency.value * 1.505;
      f.type = 'lowpass'; f.frequency.value = kind === 'orbital' ? 900 : 1600; f.Q.value = 4;
      g.gain.value = 0.0001;
      g.gain.setTargetAtTime(kind === 'orbital' ? 0.22 : 0.09, ac.currentTime, 0.03);
      o.connect(f); o2.connect(f); f.connect(g); g.connect(sfx);
      o.start(); o2.start();
      const lfo = ac.createOscillator(), lg = ac.createGain();
      lfo.frequency.value = kind === 'orbital' ? 9 : 22; lg.gain.value = 300;
      lfo.connect(lg); lg.connect(f.frequency); lfo.start();
      loops[name] = { o, o2, g, lfo };
    } else if (!on && l) {
      l.g.gain.setTargetAtTime(0.0001, ac.currentTime, 0.03);
      const t = ac.currentTime + 0.2;
      l.o.stop(t); l.o2.stop(t); l.lfo.stop(t);
      delete loops[name];
    }
  },
  stopLoops() { for (const k in loops) this.loop(k, false); },
  // ---- the opening ----
  // the dark: a choir drone, a crowd murmuring and swelling, and war drums rolling up to the first cut
  introStart() {
    if (!ac) return;
    const t = ac.currentTime;
    // the cut: a braam and the floor dropping out, then a heartbeat under a rising crowd
    braam(t + 0.3, 2.6, 0.2); subDrop(t + 0.3, 0.9);
    for (let i = 0; i < 3; i++) heart(t + 0.9 + i * 0.5, 0.5 + i * 0.15);
    choirChord(t + 0.4, 2.4, [IN_ROOT + 12, IN_ROOT + 19, IN_ROOT + 24], 0.05);
    crowd(t, 2.4, 0.06, 1.4);
    for (let i = 0; i < 10; i++) taiko(t + 0.7 + i * (0.11 - i * 0.006), 0.4 + i * 0.08, 0.85);
    introRiser(t + 0.9, 0.9, 0.12);
  },
  // a fighter cuts in: a drum hit, a brass and choir stab climbing the scale, and the crowd cheers
  introBeat(i) {
    if (!ac) return;
    const t = ac.currentTime, step = [0, 3, 5, 7, 10, 12, 15, 17][i % 8], n = IN_ROOT + 24 + step;
    taiko(t, 1.2, 1 + i * 0.03); clang(t, 0.8); brass(t, [n, n + 7, n + 12], 0.45, 0.06); tone('sine', 70, 30, 0.4, 0.6, ibus(), t);
    if (i % 4 === 3) braam(t, 0.9, 0.12, IN_ROOT - 12 + step);
    choirChord(t, 0.6, [n + 12, n + 19], 0.035);
    crowd(t + 0.05, 0.7, 0.06, 0.12);
    if (i % 2) whistles(t, 2);
  },
  // the lineup: the crowd roars and chants over a drum roll that builds to the logo
  introLineup() {
    if (!ac) return;
    const t = ac.currentTime;
    crowd(t, 1.5, 0.11, 0.3); whistles(t, 6);
    for (let i = 0; i < 3; i++) shout(t + 0.15 + i * 0.3);
    for (let i = 0; i < 12; i++) taiko(t + i * 0.085, 0.3 + i * 0.06, 1.1);
    introRiser(t, 1.05, 0.22);
    choirChord(t, 1.2, [IN_ROOT + 24, IN_ROOT + 28, IN_ROOT + 31], 0.04);
  },
  // the logo: a huge orchestral hit, the full choir, a stadium roar with whistles and the cymbals ringing out
  introLogo() {
    if (!ac) return;
    const t = ac.currentTime;
    taiko(t, 1.6, 0.8); taiko(t + 0.02, 1.2, 1.2); cymbal(t, 2.6, 0.16); clang(t, 1.2);
    braam(t, 3.2, 0.26); subDrop(t, 1.2);
    brass(t, [IN_ROOT + 12, IN_ROOT + 19, IN_ROOT + 24, IN_ROOT + 28], 1.6, 0.06);
    choirChord(t, 3, [IN_ROOT + 24, IN_ROOT + 28, IN_ROOT + 31, IN_ROOT + 36], 0.05);
    tone('sawtooth', mtof(IN_ROOT - 12), mtof(IN_ROOT - 12), 2.5, 0.12, ibus(), t, 0.01);
    crowd(t + 0.05, 3, 0.12, 0.2); whistles(t + 0.2, 10);
    for (let i = 0; i < 2; i++) shout(t + 1.4 + i * 0.4);
  },

  swing(n) {
    if (!gate('sw', 0.02)) return;
    const h = n === 2;
    hiss(h ? 0.2 : 0.12, h ? 0.55 : 0.38, 'bandpass', h ? 450 : 800, h ? 5200 : 3800, 1.5);
    tone('sine', h ? 900 : 1300, h ? 380 : 620, 0.09, 0.05);
  },
  heavySwing() { if (gate('hsw', 0.05)) { hiss(0.3, 0.6, 'bandpass', 250, 2400, 1.2); tone('sine', 300, 120, 0.25, 0.15, crunch); } },
  hit(heavy, crit) {
    if (!gate('hit', 0.03)) return;
    tone('sine', heavy ? 200 : 175, 40, heavy ? 0.2 : 0.13, 1, crunch);
    hiss(0.07, 0.5, 'highpass', 2600, 1200, 0.7);
    tone('square', rnd(1400, 1800), 600, 0.05, 0.06);
    if (crit) tone('triangle', 2400, 2300, 0.3, 0.12);
  },
  tick() { if (gate('tick', 0.045)) { tone('sine', 220, 80, 0.06, 0.4, crunch); hiss(0.03, 0.2, 'highpass', 3000, 2000, 1); } },
  kill(combo = 0) {
    if (!gate('kill', 0.04)) return;
    const t = ac.currentTime, pm = 1 + Math.min(combo, 60) * 0.008;
    v('sine', 130, 26, 0.36, 1, t, { dest: crunch });
    n(0.3, 0.5, 'lowpass', 4200, 180, 0.8, t);
    n(0.2, 0.22, 'bandpass', 7000, 2200, 2.5, t + 0.02, { rev: 0.5 });
    v('triangle', 1320 * pm, 1310 * pm, 0.14, 0.06, t + 0.03, { rev: 0.6 });
  },
  // a charged attack: a rising whine while it builds, a bright ping when it's full
  charge(f) { if (gate('chg', 0.09)) tone('triangle', 260 + f * 700, 300 + f * 760, 0.08, 0.04 + f * 0.04); },
  chargeFull() { if (!ac) return; tone('sine', 1760, 1760, 0.4, 0.14); tone('triangle', 2640, 2600, 0.25, 0.07); hiss(0.08, 0.3, 'highpass', 5000, 7000, 1); },
  slice() { if (gate('slice', 0.04)) hiss(0.1, 0.35, 'bandpass', 5000, 9500, 2); },
  dash() { if (gate('dash', 0.05)) { hiss(0.17, 0.32, 'bandpass', 280, 1900, 1.2); tone('sine', 300, 760, 0.12, 0.05); } },
  parry() {
    if (!gate('parry', 0.04)) return;
    tone('sine', 1320, 1320, 0.55, 0.22); tone('sine', 1980, 1975, 0.35, 0.12);
    tone('square', 700, 1400, 0.06, 0.08); hiss(0.05, 0.4, 'highpass', 4000, 4000, 1);
  },
  perfect() { if (!ac) return; tone('triangle', 500, 1600, 0.35, 0.15); tone('sine', 1600, 1600, 0.6, 0.08, sfx, ac.currentTime + 0.12); hiss(0.4, 0.2, 'bandpass', 2200, 600, 3); },
  rift() { if (!ac) return; hiss(0.18, 0.45, 'bandpass', 600, 7000, 1.5); tone('sine', 300, 1800, 0.18, 0.12); },
  riftCut() { if (!ac) return; tone('sine', 3200, 2800, 0.6, 0.12); tone('triangle', 1600, 1500, 0.4, 0.1); hiss(0.12, 0.5, 'highpass', 3000, 6000, 1); last.boom = -1; this.boom(0.8); },
  zap() {
    if (!ac) return;
    const t = ac.currentTime;
    for (let i = 0; i < 7; i++) tone('square', rnd(200, 1400), rnd(90, 300), 0.05, 0.07, sfx, t + i * 0.03);
    hiss(0.32, 0.4, 'highpass', 3000, 8000, 4); tone('sawtooth', 95, 40, 0.3, 0.35, crunch);
  },
  zip() { if (gate('zip', 0.06)) { tone('square', rnd(800, 1600), rnd(200, 400), 0.06, 0.05); hiss(0.06, 0.15, 'highpass', 5000, 5000, 2); } },
  boom(sz = 1) { if (gate('boom', 0.05)) { tone('sine', 100, 24, 0.3 * sz + 0.1, 1, crunch); hiss(0.4 * sz, 0.7, 'lowpass', 2600, 90, 0.7); } },
  wall() { if (gate('wall', 0.05)) { tone('sine', 90, 38, 0.16, 0.9, crunch); hiss(0.1, 0.5, 'lowpass', 1500, 300, 1); } },
  gun() { if (gate('gun', 0.03)) { tone('square', 900, 120, 0.06, 0.18, crunch); hiss(0.07, 0.45, 'bandpass', 3000, 900, 0.8); } },
  minigun() { if (gate('mg', 0.028)) { tone('square', 700, 100, 0.04, 0.14, crunch); hiss(0.04, 0.35, 'bandpass', 2500, 800, 0.8); } },
  shotgun() { if (!ac) return; tone('sine', 140, 30, 0.3, 1, crunch); hiss(0.25, 0.8, 'lowpass', 6000, 300, 0.6); tone('square', 400, 60, 0.12, 0.2, crunch); },
  reload() { if (!ac) return; tone('square', 1200, 1200, 0.03, 0.06); tone('square', 800, 800, 0.04, 0.07, sfx, ac.currentTime + 0.12); },
  click() { if (gate('click', 0.1)) tone('square', 2200, 2200, 0.02, 0.05); },
  toss() { if (gate('toss', 0.08)) { hiss(0.15, 0.2, 'bandpass', 800, 1600, 2); tone('sine', 600, 900, 0.1, 0.05); } },
  magic() { if (gate('magic', 0.05)) { tone('triangle', rnd(700, 900), 1400, 0.12, 0.08); tone('sine', 1800, 2400, 0.08, 0.04); } },
  freeze() { if (!ac) return; hiss(0.4, 0.4, 'highpass', 6000, 2000, 2); tone('sine', 2400, 1200, 0.4, 0.1); tone('triangle', 3200, 3000, 0.5, 0.05); },
  meteorFall() { if (gate('mf', 0.08)) hiss(0.5, 0.25, 'bandpass', 400, 2400, 2); },
  shuriken() { if (gate('shu', 0.05)) { hiss(0.08, 0.3, 'bandpass', 3000, 6000, 3); tone('square', 1800, 1200, 0.04, 0.04); } },
  smoke() { if (!ac) return; hiss(0.6, 0.5, 'lowpass', 1500, 200, 0.7); tone('sine', 300, 80, 0.3, 0.2); },
  build() { if (!ac) return; const t = ac.currentTime; for (let i = 0; i < 3; i++) tone('square', 300 + i * 120, 200, 0.05, 0.1, crunch, t + i * 0.07); },
  pew() { if (gate('pew', 0.05)) tone('square', 1400, 500, 0.06, 0.05); },
  shieldUp() { if (!ac) return; tone('sine', 300, 900, 0.3, 0.15); tone('triangle', 600, 1800, 0.3, 0.06); },
  shieldHit() { if (gate('shh', 0.06)) { tone('triangle', 1600, 800, 0.15, 0.15); hiss(0.08, 0.3, 'highpass', 3000, 3000, 1); } },
  rocket() { if (gate('rk', 0.04)) { hiss(0.3, 0.35, 'bandpass', 600, 3000, 1.5); tone('sawtooth', 200, 400, 0.15, 0.05); } },
  overheat() { if (!ac) return; hiss(0.6, 0.4, 'highpass', 2000, 6000, 1); tone('square', 600, 200, 0.4, 0.08); },
  pickup(n) {
    if (!gate('pk', 0.022)) return;
    const f = 660 * Math.pow(2, Math.min(n, 24) / 12);
    tone('triangle', f, f, 0.09, 0.1); tone('sine', f * 2, f * 2, 0.05, 0.04);
  },
  heal() { if (!ac) return; tone('sine', 523, 523, 0.15, 0.15); tone('sine', 784, 784, 0.25, 0.15, sfx, ac.currentTime + 0.08); },
  hurt() { if (!ac) return; tone('sawtooth', 260, 70, 0.3, 0.45, crunch); hiss(0.25, 0.5, 'lowpass', 1800, 200, 1); },
  death() { if (!ac) return; tone('sawtooth', 220, 30, 1.6, 0.5, crunch); hiss(1.4, 0.5, 'lowpass', 3000, 80, 0.7); },
  rank(r) {
    if (!ac) return;
    const base = 74 + [0, 0, 2, 3, 5, 7, 10][r];
    tone('triangle', mtof(base), mtof(base), 0.08, 0.12);
    tone('triangle', mtof(base + 7), mtof(base + 7), 0.18, 0.12, sfx, ac.currentTime + 0.07);
  },
  deny() { if (gate('deny', 0.12)) tone('square', 180, 140, 0.08, 0.07); },
  ui() { if (gate('ui', 0.03)) tone('square', 880, 880, 0.03, 0.05); },
  select() { if (!ac) return; tone('square', 660, 660, 0.05, 0.06); tone('square', 990, 990, 0.1, 0.06, sfx, ac.currentTime + 0.05); },
  sigil() { if (gate('sig', 0.12)) { tone('sine', 220, 440, 0.4, 0.04); hiss(0.4, 0.05, 'bandpass', 800, 2400, 6); } },
  spawn() { if (gate('spn', 0.06)) { hiss(0.12, 0.2, 'lowpass', 1200, 300, 1); tone('sine', 300, 90, 0.12, 0.14); } },
  shoot() { if (gate('shoot', 0.05)) tone('triangle', 520, 240, 0.14, 0.07); },
  fuse() { if (gate('fuse', 0.08)) tone('square', 1200, 1200, 0.04, 0.05); },
  step() { if (gate('step', 0.1)) hiss(0.03, 0.05, 'lowpass', 900, 400, 1); },
  splat() { if (gate('splat', 0.05)) { hiss(0.15, 0.3, 'lowpass', 900, 200, 2); tone('sine', 180, 60, 0.1, 0.2); } },
  warn() { if (gate('warn', 0.2)) { tone('square', 880, 880, 0.08, 0.06); tone('square', 660, 660, 0.08, 0.06, sfx, ac.currentTime + 0.1); } },
  waveStart(boss) {
    if (!ac) return;
    if (boss) { this.bossRoar(); return; }
    tone('triangle', 147, 147, 0.5, 0.12); tone('triangle', 220, 220, 0.6, 0.1, sfx, ac.currentTime + 0.12);
  },
  waveClear() { if (!ac) return; const t = ac.currentTime; [62, 65, 69, 74, 77].forEach((n, i) => tone('triangle', mtof(n), mtof(n), 0.4, 0.1, sfx, t + i * 0.07)); },
  victory() { if (!ac) return; const t = ac.currentTime; [62, 66, 69, 74, 78, 81, 86].forEach((n, i) => { tone('triangle', mtof(n), mtof(n), 0.8, 0.1, sfx, t + i * 0.12); tone('sine', mtof(n + 12), mtof(n + 12), 0.6, 0.05, sfx, t + i * 0.12); }); },
  bossRoar() {
    if (!ac) return;
    tone('sawtooth', 75, 45, 1.3, 0.5, crunch, ac.currentTime, 0.1);
    tone('sawtooth', 112, 60, 1.2, 0.3, crunch, ac.currentTime, 0.1);
    hiss(1.2, 0.4, 'lowpass', 700, 120, 2, sfx, ac.currentTime, 0.1);
  },
  // multi-kills: a power chord that climbs with the count
  multi(n) {
    if (!ac || !gate('multi', 0.06)) return;
    const t = ac.currentTime, b = 62 + Math.min(n, 10) * 2;
    [0, 7, 12].forEach((iv, i) => tone('triangle', mtof(b + iv), mtof(b + iv), 0.32, 0.09, sfx, t + i * 0.025));
    tone('square', mtof(b + 24), mtof(b + 19), 0.12, 0.05, sfx, t);
    hiss(0.18, 0.25, 'bandpass', 3000, 9000, 2, sfx, t);
    if (n >= 5) tone('sawtooth', mtof(b - 12), mtof(b - 24), 0.5, 0.18, crunch, t);
  },
  heartbeat() { if (!ac) return; const t = ac.currentTime; tone('sine', 62, 38, 0.14, 0.5, crunch, t); tone('sine', 58, 34, 0.12, 0.35, crunch, t + 0.16); },
  coin() { if (gate('coin', 0.05)) { tone('square', 1976, 1976, 0.04, 0.05); tone('square', 2637, 2637, 0.12, 0.05, sfx, ac.currentTime + 0.05); } },
  jackpot() {
    if (!ac) return;
    const t = ac.currentTime;
    [72, 76, 79, 84, 88, 91, 96].forEach((n, i) => { tone('square', mtof(n), mtof(n), 0.1, 0.06, sfx, t + i * 0.045); tone('triangle', mtof(n), mtof(n), 0.3, 0.07, sfx, t + i * 0.045); });
    this.boom(0.6);
  },
  twist() {
    if (!ac) return;
    const t = ac.currentTime;
    tone('sawtooth', 110, 55, 1, 0.25, crunch, t); tone('triangle', mtof(69), mtof(68), 0.9, 0.1, sfx, t + 0.1); tone('triangle', mtof(75), mtof(74), 0.9, 0.08, sfx, t + 0.2);
    hiss(0.8, 0.3, 'bandpass', 400, 3000, 3, sfx, t);
  },
  ultStart() { if (!ac) return; tone('sine', 70, 30, 1.2, 0.8, crunch); hiss(0.5, 0.4, 'bandpass', 200, 6000, 2, sfx, ac.currentTime, 0.4); },
  ultCut(i) { if (!ac) return; hiss(0.05, 0.4, 'bandpass', 6000, 9500, 3); tone('sine', 1800 + i * 70, 1700 + i * 70, 0.07, 0.05); },
  ultRelease() { if (!ac) return; last.boom = -1; this.boom(2.6); tone('sine', 2600, 2400, 1.3, 0.1); hiss(1, 0.5, 'lowpass', 8000, 200, 0.7); },
};

// ---------- signature sounds: every fighter attacks and hits differently ----------
function v(type, f0, f1, dur, vol, t, o = {}) {
  const osc = ac.createOscillator();
  osc.type = type; osc.frequency.setValueAtTime(f0, t);
  if (f1 && f1 !== f0) osc.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
  const e = ac.createGain();
  env(e, t, o.a ?? 0.002, vol, dur);
  osc.connect(e); e.connect(o.dest || sfx);
  if (o.rev && sfxRev) { const g = ac.createGain(); g.gain.value = o.rev; e.connect(g); g.connect(sfxRev); }
  osc.start(t); osc.stop(t + dur + 0.05);
}
function n(dur, vol, type, f0, f1, q, t, o = {}) {
  hiss(dur, vol, type, f0, f1, q, o.dest || sfx, t, o.a ?? 0.002);
  if (o.rev && sfxRev) hiss(dur, vol * o.rev, type, f0, f1, q, sfxRev, t, o.a ?? 0.002);
}
// inharmonic partials ring like struck metal
const metal = (fs, dur, vol, t, rev = 0.4) => fs.forEach((f) => v('sine', f, f * 0.997, dur, vol / fs.length, t, { rev }));
const semi = (f, s) => f * Math.pow(2, s / 12);

// a blade cutting air: the noise band rises as the edge speeds up, then falls away
function whoosh(dur, vol, lo, hi, q, t, o) {
  n(dur * 0.4, vol * 0.7, 'bandpass', lo, hi, q, t, o);
  n(dur * 0.6, vol, 'bandpass', hi, lo * 0.8, q, t + dur * 0.35, o);
}
// quick mechanical ticks: a revolver cylinder, a wrench ratchet
function clicks(count, gap, f, vol, t) {
  for (let i = 0; i < count; i++) { v('square', f * (1 + (i % 2) * 0.12), f, 0.006, vol, t + i * gap); n(0.008, vol * 2, 'highpass', 4000, 4000, 1, t + i * gap); }
}

// The sound follows the weapon in hand: longsword, katana, revolver, staff magic, wrench, hammer, laser, code.
const ATK = {
  // KAEL, longsword: a fast hiss of air with a thin steel "shing" on the opener and the finisher
  BLADE(h, step, t) {
    if (h) {
      whoosh(0.34, 0.75, 350, 2600, 1.8, t);
      v('sawtooth', 110, 55, 0.22, 0.12, t, { dest: crunch });
    } else whoosh(0.2, 0.6, 700, 3400 + step * 300, 2.2, t);
    v('sine', 1900 + step * 150, 900, 0.14, 0.025, t + 0.02);
    if (h || step === 0) metal([4300, 5750, 7200], 0.3, 0.045, t, 0.5);
  },
  // RIN, katana: a thin, fast swish with a bright steel shing. The finisher is a quick-draw:
  // the blade scrapes out of the scabbard, then cuts.
  NINJA(h, step, t) {
    if (h) {
      n(0.1, 0.35, 'bandpass', 2000, 8000, 6, t);
      metal([3700, 5100, 6800], 0.12, 0.05, t, 0.3);
      whoosh(0.2, 0.6, 1100, 6500, 3, t + 0.09);
      metal([5400, 7300, 9100], 0.45, 0.06, t + 0.1, 0.7);
    } else {
      whoosh(0.13, 0.5, 1400, 6000 + step * 400, 3, t);
      metal([5200 + step * 200, 6900 + step * 250], 0.18, 0.035, t + 0.01, 0.5);
    }
  },
  // VEGA, revolver: hammer click, muzzle crack, chest thump, echo, then the cylinder turns
  GUNNER(h, step, t) {
    v('square', 3200, 3200, 0.005, 0.08, t);
    n(0.018, 1, 'highpass', 2500, 2500, 0.7, t + 0.006);
    n(0.09, 0.7, 'lowpass', 3200, 380, 0.7, t + 0.006, { dest: crunch });
    v('sine', 150, 40, 0.18, 0.85, t + 0.006, { dest: crunch });
    n(0.4, 0.22, 'bandpass', 1300, 280, 0.6, t + 0.04, { rev: 0.9 });
    clicks(2, 0.025, 2600, 0.035, t + 0.12);
  },
  // MORROW, staff magic: a resonant rising swirl with a shimmering arpeggio
  WIZARD(h, step, t) {
    n(0.2, 0.3, 'bandpass', 400, 3200, 5, t, { rev: 0.5 });
    v('sine', 180, 380, 0.16, 0.12, t);
    [0, 4, 7, 12].forEach((s, i) => {
      const f = semi(1046, s);
      v('sine', f, f, 0.12, 0.05, t + i * 0.022, { rev: 0.7 });
      v('sine', f * 1.007, f * 1.007, 0.12, 0.03, t + i * 0.022);
    });
    n(0.18, 0.1, 'highpass', 7000, 10000, 1, t + 0.04, { rev: 0.6 });
  },
  // RIVET, wrench: a ratchet clicks, then a heavy tool swing
  MECHANIC(h, step, t) {
    clicks(h ? 5 : 3, 0.016, 1900, 0.035, t);
    whoosh(h ? 0.32 : 0.22, 0.55, 280, 1500, 1.4, t + 0.03);
  },
  // GROM, war hammer: a slow, huge swing you feel in the chest
  TANK(h, step, t) {
    whoosh(h ? 0.5 : 0.38, 0.75, 130, 750, 1.2, t);
    v('sine', 75, 42, h ? 0.4 : 0.3, 0.3, t, { dest: crunch });
    if (h) n(0.3, 0.2, 'lowpass', 600, 90, 1, t + 0.15, { rev: 0.4 });
  },
  // UNIT-7 keeps the beam hum loop; this is the charge chirp
  ROBOT(h, step, t) { v('sawtooth', 300, 1500, 0.07, 0.05, t); v('square', 2400, 3600, 0.04, 0.02, t + 0.04); },
  // THE DEV, ping: a packet goes out as 8-bit blips
  DEV(h, step, t) {
    const f = [988, 1319, 1568, 1175][step % 4];
    v('square', f, f, 0.03, 0.07, t); v('square', f * 2, f * 2, 0.02, 0.035, t + 0.032);
    n(0.015, 0.15, 'highpass', 6000, 6000, 1, t);
  },
};
const HIT = {
  // katana through flesh: a razor hiss, a wet cut, a thump, and the steel rings out
  BLADE(h, crit, pm, t) {
    n(0.035, 0.75, 'highpass', 5200, 2600, 0.8, t);
    n(0.1, 0.5, 'bandpass', 1900 * pm, 550, 1.4, t + 0.008);
    v('sine', 170 * pm, 42, h ? 0.22 : 0.13, 0.95, t, { dest: crunch });
    metal([2350 * pm, 3510 * pm, 4790 * pm], h ? 0.4 : 0.24, 0.13, t, 0.5);
    if (crit) metal([4700 * pm, 6300 * pm], 0.6, 0.12, t + 0.01, 0.8);
  },
  // katana slice: a razor-clean "tsk", a short cut, and a high ring that lingers on heavies and crits
  NINJA(h, crit, pm, t) {
    n(0.03, 0.75, 'highpass', 7000, 3500, 1, t);
    n(0.07, 0.45, 'bandpass', 2600 * pm, 900, 1.8, t + 0.006);
    v('sine', 220 * pm, 60, h ? 0.14 : 0.08, 0.7, t, { dest: crunch });
    metal([3100 * pm, 4650 * pm, 6200 * pm], h || crit ? 0.5 : 0.18, h || crit ? 0.14 : 0.08, t, 0.6);
  },
  // bullet impact: a hard thwack; crits ricochet away
  GUNNER(h, crit, pm, t) {
    n(0.03, 0.6, 'bandpass', 3600 * pm, 1400, 1.5, t);
    v('sine', 300 * pm, 70, 0.08, 0.7, t, { dest: crunch });
    n(0.07, 0.3, 'lowpass', 1500, 200, 1, t);
    if (crit) v('sine', 3400, 1700, 0.25, 0.06, t + 0.02, { rev: 0.7 });
  },
  // arcane burst: a soft pop, a sparkling bell chord that hangs in the air
  WIZARD(h, crit, pm, t) {
    v('sine', 420, 80, 0.09, 0.6, t, { dest: crunch });
    [0, 7, 12, 16].forEach((s, i) => v('sine', semi(660 * pm, s), semi(660 * pm, s), 0.4, 0.055, t + i * 0.015, { rev: 0.8 }));
    n(0.14, 0.28, 'bandpass', 5000, 11000, 3, t, { rev: 0.5 });
    if (crit) [19, 24].forEach((s, i) => v('triangle', semi(660 * pm, s), semi(660 * pm, s), 0.5, 0.05, t + 0.05 + i * 0.03, { rev: 0.9 }));
  },
  // wrench on armor: a bright tool clang and a rattle
  MECHANIC(h, crit, pm, t) {
    metal([470 * pm, 1170 * pm, 1980 * pm, 2860 * pm], h ? 0.6 : 0.38, 0.32, t, 0.5);
    v('sine', 150, 45, 0.16, 0.9, t, { dest: crunch });
    n(0.08, 0.3, 'bandpass', 2400, 1200, 2, t + 0.02);
  },
  // hammer smash: a deep boom, a dull iron clang, and debris
  TANK(h, crit, pm, t) {
    v('sine', 95 * pm, 28, h ? 0.5 : 0.34, 1, t, { dest: crunch });
    n(h ? 0.45 : 0.3, 0.7, 'lowpass', 2400, 90, 0.8, t, { rev: 0.4 });
    metal([220 * pm, 341 * pm, 517 * pm, 780 * pm], h ? 0.5 : 0.3, 0.28, t, 0.4);
    n(0.18, 0.25, 'bandpass', 1500, 600, 1.5, t + 0.04);
  },
  // laser burn: a sizzle and an electric zzt, soft enough to repeat every tick of the beam
  ROBOT(h, crit, pm, t) {
    n(0.07, 0.3, 'highpass', 3000, 7000, 1, t);
    v('sawtooth', 120 * pm, 95, 0.06, 0.08, t, { dest: crunch });
    v('square', 1600 * pm, 2600 * pm, 0.03, 0.025, t);
  },
  // the hack lands: a glitchy chiptune arpeggio
  DEV(h, crit, pm, t) {
    [0, 7, 12, 19].forEach((s, i) => v('square', semi(523 * pm, s), semi(523 * pm, s), 0.025, 0.06, t + i * 0.022));
    v('square', 3000 + Math.random() * 3000, 400, 0.04, 0.03, t);
    n(0.05, 0.2, 'highpass', 6000, 6000, 1, t);
  },
};
Object.assign(A, {
  charAtk(id, heavy, step = 0) { if (gate('atk', 0.025)) (ATK[id] || ATK.BLADE)(heavy, step, ac.currentTime); },
  // hits climb a little in pitch as the combo grows
  charHit(id, heavy, crit, combo = 0) { if (gate('chit', 0.03)) (HIT[id] || HIT.BLADE)(heavy, crit, 1 + Math.min(combo, 60) * 0.006, ac.currentTime); },
});

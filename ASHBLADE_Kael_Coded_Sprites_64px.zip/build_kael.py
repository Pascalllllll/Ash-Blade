#!/usr/bin/env python3
"""ASHBLADE Kael sprite pipeline; source is a visual mock-up, output is an approximate traced reconstruction."""
from pathlib import Path
import base64, json, zipfile, math, textwrap, shutil
import numpy as np
import cv2
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'kael_reference_sheet.png'
if not SOURCE.exists():
    shutil.copyfile('/mnt/data/lembar_sprite_animasi_kael_si_pendekar.png', SOURCE)
OUT=ROOT/'assets';OUT.mkdir(exist_ok=True,parents=True)
source=np.array(Image.open(SOURCE).convert('RGB'))
CENTERS_BY_ROW={
 'idle':[288,416,544,672,800,928,1057,1185],
 'walk':[288,416,544,672,800,928,1057,1185],
 'run':[288,416,544,672,800,928,1057,1185],
 'attack1':[289,417,546,675,804,933,1062,1190],
 'attack2':[290,419,548,677,806,935,1064,1193],
 'attack3':[290,419,548,678,807,936,1065,1194],
 'skill1':[292,422,552,681,811,940,1070,1200],
 'skill2':[292,423,552,683,812,942,1072,1202],
 'dash':[293,423,553,684,814,943,1073,1202],
 'hit':[293,423,553,684,814,944,1073,1202],
}
ROWS={
 'idle': (150,239,7,8), 'walk': (239,333,7,8), 'run':(333,427,7,8),
 'attack1':(427,517,8,8),'attack2':(517,605,8,8),'attack3':(605,696,8,8),
 'skill1':(696,782,6,6),'skill2':(782,869,8,8),
 'dash':(869,957,6,6),'hit':(957,1054,4,4),
}
SCALE_X=.67; SCALE_Y=.82
FRAME=64
# Pixel colors sampled from Kael sheet, boot and outline hand-coded.
OUTLINE=(14,5,19,255); BOOT=(36,17,43,255); BOOT_LIGHT=(78,37,70,255)


def rgba_crop(clip, i):
    y0,y1,n,total=ROWS[clip]
    cx=CENTERS_BY_ROW[clip][i]
    x0,x1=cx-54,cx+54
    top,bottom=y0+11,y1-9
    a=source[top:bottom,x0:x1].copy()
    # Character and actual attack-effect pixels are MUCH brighter than black panel interior.
    mx=a.max(axis=2); mn=a.min(axis=2)
    sat=mx.astype('int16')-mn.astype('int16')
    candidates=(mx>=43) | ((mx>=29)&(sat>=22))
    # Remove thin cell borders and grid corner decorations; never export UI into sprites.
    candidates[:2,:]=False; candidates[-1:,:]=False
    candidates[:,:3]=False; candidates[:,-3:]=False
    # Unify and keep main torso/hair component and nearby secondary parts / VFX.
    candidates=cv2.morphologyEx(candidates.astype('uint8'),cv2.MORPH_CLOSE,np.ones((2,2),np.uint8))>0
    num, lab, stats, cent =cv2.connectedComponentsWithStats(candidates.astype('uint8'),8)
    keep=np.zeros_like(candidates)
    # Exclude long border lines. Largest meaningful central component = character.
    comps=[]
    for q in range(1,num):
        px,py,w,h,area=stats[q];cxr,cyr=cent[q]
        border=(w>=len(a[0])*.70 and h<9) or (h>=len(a)*.75 and w<9)
        if not border and area>14:
            comps.append((area,q,cxr,cyr,px,py,w,h))
    candidates_center=[c for c in comps if abs(c[2]-len(a[0])/2)<39 and c[0]>140]
    main=max(candidates_center or comps, default=None)
    if main:
        _,mid,cent_x,cent_y,*_=main
        keep|=(lab==mid)
        for ar,q,qx,qy,px,py,w,h in comps:
            if q==mid:continue
            # Allow detached attack arcs, sparks or sword tip near the hero, exclude panel corners.
            if ar>=20 and abs(qx-len(a[0])/2)<46 and abs(qy-cent_y)<49 and not (px<5 and py<5):
                keep|=(lab==q)
    # Repair dark outline and face details excluded by threshold. Inward holes should be opaque.
    keep=cv2.morphologyEx(keep.astype('uint8'),cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))>0
    contours,hierarchy=cv2.findContours(keep.astype('uint8'),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    filled=np.zeros_like(keep,dtype=np.uint8)
    cv2.drawContours(filled,contours,-1,1,cv2.FILLED)
    filled=filled>0
    # 1 px outline extends under original character contour, no antialiased halo.
    halo=cv2.dilate(filled.astype('uint8'),np.ones((3,3),np.uint8),iterations=1)>0
    rgb=np.zeros((*keep.shape,4),dtype=np.uint8)
    rgb[filled,:3]=a[filled]
    rgb[filled,3]=255
    rgb[halo &~filled,:3]=OUTLINE[:3]
    rgb[halo&~filled,3]=255
    # Resize once, consistently; source frame's artist already varies the poses.
    interp=cv2.INTER_NEAREST
    d=cv2.resize(rgb,None,fx=SCALE_X,fy=SCALE_Y,interpolation=interp)
    f=np.zeros((64,64,4),dtype=np.uint8)
    src_ground=y1-14
    # Keep feet at y=63 and character center at x=32; do NOT recenter on variable VFX bbox.
    ox=round(32-(54*SCALE_X))
    oy=round(63-((src_ground-top)*SCALE_Y))
    xL=max(0,ox);xR=min(64,ox+d.shape[1]);yT=max(0,oy);yB=min(64,oy+d.shape[0]);
    if xR>xL and yB>yT:
        layer=d[yT-oy:yB-oy,xL-ox:xR-ox]
        f[yT:yB,xL:xR]=layer
    if clip=='hit':
        # Remove a long decorative border accidentally touching the top of two HIT cells.
        for yy in range(0,14):
            if np.count_nonzero(f[yy,:,3])>=52:
                f[yy,:,:]=0
    return Image.fromarray(f,'RGBA')


def finish_missing(frames, clip):
    # The illustration depicts 7 poses in each 8-frame locomotion/idle row.
    # Construct an explicit extra frame (not a silently duplicated placeholder).
    if len(frames)==8:return frames
    assert len(frames)==7
    new=frames[2].copy()
    if clip=='idle':
        new=new.transform(new.size,Image.Transform.AFFINE,(1,0,0,0,1,1),resample=Image.Resampling.NEAREST)
    else:
        new=paint_feet(new, -2 if clip=='walk' else -3, +2 if clip=='walk' else +3, True)
    frames.append(new)
    return frames


def paint_feet(im, left, right, extra=False):
    """Explicit pixel animation of left/right boot phase to fix weak leg changes in source art."""
    out=im.copy();d=ImageDraw.Draw(out)
    # Grounded tiny Soul Knight boots, eyes always face camera.
    # Small torso-front underlay conceals inconsistent leg drawings from the concept sheet.
    # Don't erase sword outside lower center.
    d.rectangle((26,56,39,62),fill=OUTLINE)
    def leg(cx,off,other):
        xx=cx+off; top=56+(abs(off)//2)
        d.rectangle((xx,top,xx+4,61),fill=OUTLINE)
        d.rectangle((xx+1,top+1,xx+3,60),fill=BOOT)
        d.line((xx+1,top+1,xx+2,top+1), fill=BOOT_LIGHT)
        d.rectangle((xx-1,61,xx+5,63),fill=OUTLINE)
        d.rectangle((xx,61,xx+4,62),fill=BOOT)
    leg(26,left,False);leg(34,right,True)
    return out

frames={}
for clip,(y0,y1,available,n) in ROWS.items():
    ff=[rgba_crop(clip,i) for i in range(available)]
    if clip in ('idle','walk','run'):
        ff=finish_missing(ff,clip)
    if clip in ('walk','run'):
        for j,im in enumerate(ff):
            # Cyclic alternation: front-facing character does not turn sideways.
            phase=2*math.pi*j/8
            amp=2 if clip=='walk' else 3
            le=round(amp*math.sin(phase));ri=-le
            ff[j]=paint_feet(im,le,ri)
    frames[clip]=ff
# Skill 1 is the dash action, as requested; no separate inconsistent animation.
frames['skill1']=[im.copy() for im in frames['dash']]

# Validate all frames BEFORE export.
assert len(frames)==10
for name, seq in frames.items():
    assert len(seq)==ROWS[name][3], (name,len(seq))
    assert all(im.size==(64,64) and im.mode=='RGBA' for im in seq)

# One sprite strip per action, no labels, 64px pitch, transparency.
for name,seq in frames.items():
    strip=Image.new('RGBA',(64*len(seq),64),(0,0,0,0))
    for i,im in enumerate(seq):strip.alpha_composite(im,(64*i,0))
    strip.save(OUT/f'{name}.png')

# A single atlas with 10 rows and 8 columns, blanks retained as fully transparent cells.
atlas=Image.new('RGBA',(512,640),(0,0,0,0))
for y,(name,seq) in enumerate(frames.items()):
    for x,im in enumerate(seq):atlas.alpha_composite(im,(x*64,y*64))
atlas.save(OUT/'kael.png')

# Detailed metadata and suggested action speeds; all 10 sequences, 72 frames.
DUR={'idle':110,'walk':95,'run':65,'attack1':75,'attack2':75,'attack3':75,'skill1':48,'skill2':100,'dash':48,'hit':115}
metadata={'character':'kael','orientation':'front','frameWidth':64,'frameHeight':64,'anchor':{'x':32,'y':63},'format':'RGBA','atlas':'kael.png','columns':8,'rows':10,
 'combos':['attack1','attack2','attack3'],'skills':{'skill1':'dash','skill2':'barehand_lightning'},
 'source':'reconstructed from the uploaded visual mockup; no guaranteed per-pixel identity to original art',
 'animations':{name:{'row':i,'frames':len(seq),'frameMs':DUR[name], 'loop':name in ('idle','walk','run'), 'strip':f'{name}.png',
                        'frameRects':[{'x':j*64,'y':i*64,'w':64,'h':64} for j in range(len(seq))]} for i,(name,seq) in enumerate(frames.items())}}
(OUT/'kael.json').write_text(json.dumps(metadata,indent=2))

# Self-contained ES module: everything stored as exact pixel-color DATA, independent of source PNG.
# Global 128-color palette for efficient RLE code. Never perform in-game image recognition.
all_frames=[frame for seq in frames.values() for frame in seq]
# Use PIL to construct a global palette from all opaque pixels.
colors=np.concatenate([np.array(im,dtype=np.uint8).reshape(-1,4) for im in all_frames])
opaque=colors[colors[:,3]>0][:,:3]
rng=np.random.default_rng(0)
sub=opaque[rng.choice(len(opaque),min(len(opaque),100000),replace=False)]
# Create a 3-channel sample image to quantize into a global 127-color palette.
sample=Image.fromarray(sub.reshape((1,len(sub),3)),'RGB')
q=sample.quantize(colors=127,method=Image.Quantize.MEDIANCUT)
palbytes=q.getpalette()[:127*3]
palette=[tuple(palbytes[i*3:i*3+3]) for i in range(127)]
# nearest palette using palette KD-tree
from scipy.spatial import cKDTree
tree=cKDTree(np.array(palette,dtype=np.float32))

def encode_pixel(im):
    arr=np.array(im,dtype=np.uint8);pix=arr[:,:,:3].reshape(-1,3)
    al=arr[:,:,3].reshape(-1)
    ids=np.zeros(len(pix),dtype=np.uint8)
    sel=al>0
    ids[sel]=tree.query(pix[sel],workers=1)[1].astype(np.uint8)+1
    # RLE [count:uint8][index:uint8], 4096 pixels exactly.
    result=bytearray();last=int(ids[0]);count=0
    for value in ids:
        v=int(value)
        if v==last and count<255:count+=1
        else:
            result.extend((count,last));last=v;count=1
    result.extend((count,last))
    return base64.b64encode(result).decode('ascii')

enc={name:[encode_pixel(im) for im in seq] for name,seq in frames.items()}
module='''// ASHBLADE Kael — CODED SPRITES: transparent 64x64 frames as RLE palette-indexed data.
// Generated from the concept-art template and edited to standardize the gait.
// No external PNG required and NO image detection during gameplay.
// Each pair of bytes in a base64 string = (runLength, paletteIndex), index 0 means transparent.
export const FRAME_SIZE=64;
export const ANIMATION_INFO=__META__;
export const COLOR_PALETTE=__PAL__;
export const CODED_FRAMES=__DATA__;
export const KAEL={w:64,h:64,palette:COLOR_PALETTE,frames:CODED_FRAMES,info:ANIMATION_INFO};
export function decodeFrame(animation, index=0) {
  const seq=CODED_FRAMES[animation];
  if (!seq) throw new Error(`Unknown Kael animation: ${animation}`);
  const b64=seq[((index%seq.length)+seq.length)%seq.length];
  const bytes=typeof atob==='function'?Uint8Array.from(atob(b64),c=>c.charCodeAt(0)):Uint8Array.from(Buffer.from(b64,'base64'));
  const rgba=new Uint8ClampedArray(64*64*4); let at=0;
  for(let p=0;p<bytes.length;p+=2){
    const count=bytes[p], id=bytes[p+1];
    for(let j=0;j<count;j++,at++){
      if (id===0) continue;
      const c=COLOR_PALETTE[id-1], pos=at*4;
      rgba[pos]=c[0];rgba[pos+1]=c[1];rgba[pos+2]=c[2];rgba[pos+3]=255;
    }
  }
  if(at!==4096)throw new Error(`Corrupt RLE frame: ${animation}/${index} length ${at}`);
  return rgba;
}
export function frameToImageData(animation,index=0){
  return new ImageData(decodeFrame(animation,index),64,64);
}
export function drawFrame(ctx,animation,index,x,y,scale=3){
  const pixels=decodeFrame(animation,index);
  const off=document.createElement('canvas');off.width=64;off.height=64;
  const oc=off.getContext('2d');oc.putImageData(new ImageData(pixels,64,64),0,0);
  ctx.imageSmoothingEnabled=false;
  ctx.drawImage(off,Math.round(x),Math.round(y),64*scale,64*scale);
}
export function getFrame(animation,elapsedMs){
  const info=ANIMATION_INFO.animations[animation];
  if(!info)throw new Error(`Unknown animation ${animation}`);
  const idx=Math.floor(elapsedMs/info.frameMs);
  return info.loop?idx%info.frames:Math.min(idx,info.frames-1);
}
'''
module=module.replace('__META__',json.dumps(metadata,ensure_ascii=False,separators=(',',':'))).replace('__PAL__',json.dumps(palette,separators=(',',':'))).replace('__DATA__',json.dumps(enc,ensure_ascii=False,separators=(',',':')))
(ROOT/'kael-sprites.mjs').write_text(module)

# Optional browser demo: local web server required for import, no dependencies.
html='''<!doctype html><html lang="en"><meta charset="utf-8"><title>ASHBLADE Kael — Coded Pixel Sprites</title>
<style>body{background:#12101b;color:#f9effc;font-family:system-ui;max-width:740px;margin:20px auto}canvas{image-rendering:pixelated;background:repeating-conic-gradient(#33323d 0% 25%,#211f2a 0% 50%) 50%/24px 24px;border:1px solid #8f49aa;border-radius:10px}button{background:#37263f;color:white;border:1px solid #9f58bb;padding:9px 11px;margin:3px;cursor:pointer;border-radius:7px}.active{background:#9d509f}</style>
<h2>ASHBLADE — Kael (Pixel Coded)</h2><p>64×64 RGBA • Front-facing • Click to play an animation • No image recognition at runtime</p><canvas id="game" width="320" height="320"></canvas><div id="controls"></div><p id="status"></p>
<script type="module">import {ANIMATION_INFO,decodeFrame,getFrame} from './kael-sprites.mjs';const canvas=document.getElementById('game'),ctx=canvas.getContext('2d'),controls=document.getElementById('controls'),status=document.getElementById('status');let action='idle',start=performance.now();
for(const name of Object.keys(ANIMATION_INFO.animations)){let b=document.createElement('button');b.textContent=name;b.onclick=()=>{action=name;start=performance.now();document.querySelectorAll('button').forEach(x=>x.classList.remove('active'));b.classList.add('active')};controls.appendChild(b)}controls.querySelector('button').click();const tmp=document.createElement('canvas');tmp.width=tmp.height=64;const tc=tmp.getContext('2d');
function tick(now){ctx.clearRect(0,0,320,320);const frame=getFrame(action,now-start),a=decodeFrame(action,frame);tc.putImageData(new ImageData(a,64,64),0,0);ctx.imageSmoothingEnabled=false;ctx.drawImage(tmp,0,0,320,320);status.textContent=`${action.toUpperCase()} · ${frame+1}/${ANIMATION_INFO.animations[action].frames} frames`;requestAnimationFrame(tick)}requestAnimationFrame(tick)
</script></html>'''
(ROOT/'preview.html').write_text(html)

# A checkered preview of the atlas, labels placed OUTSIDE frame grid.
background=Image.new('RGBA',atlas.size,(20,17,29,255));d=ImageDraw.Draw(background)
for y in range(0,640,8):
 for x in range(0,512,8):
    if (x//8+y//8)%2==0:d.rectangle((x,y,x+7,y+7),fill=(37,32,48,255))
background.alpha_composite(atlas)
background.resize((1024,1280),Image.Resampling.NEAREST).save(ROOT/'kael-preview.png')
# Verify export alpha and source data decoder lengths.
assert atlas.getchannel('A').getextrema()==(0,255)
assert sum(len(s) for s in frames.values())==72
assert all(sum(base64.b64decode(s)[::2])==4096 for seq in enc.values() for s in seq)

# zip the complete working project; source image not included because user already owns it.
zip_path=Path('/mnt/data/ASHBLADE_Kael_Coded_Sprites_64px.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for f in [ROOT/'kael-sprites.mjs',ROOT/'preview.html',ROOT/'kael-preview.png',ROOT/'build_kael.py',ROOT/'kael_reference_sheet.png',ROOT/'README.md',OUT/'kael.json',*OUT.glob('*.png')]:
        z.write(f,arcname=f.relative_to(ROOT))
print('DONE',zip_path,'size',zip_path.stat().st_size)
print('atlas',atlas.size,'frames',sum(map(len,frames.values())), 'JS size',len(module))
print('metadata', {k:len(v) for k,v in frames.items()})

# ASHBLADE / Kael Coded Sprite Pack — Visual Reconstruction

This pack is a **working 64×64 pixel-data reconstruction**, NOT a frame-for-frame proof of exact source art reproduction. The only source was a rendered infographic with some frame counts mislabeled and opaque backgrounds; the reconstruction segments its characters, creates additional gait variations, and keeps the animation list in the latest design.

## Contents
- `kael-sprites.mjs`: all 72 RGBA frames stored as self-contained palette-indexed RLE data; **no image recognition at runtime**. Exports `KAEL`, `decodeFrame`, `getFrame`, `drawFrame`, `frameToImageData`.
- `assets/kael.png`: 8-column × 10-row fully transparent sprite atlas, each tile **64×64**, total **512×640**.
- `assets/<animation>.png`: 10 individually organized transparent strips, 64px per sprite.
- `assets/kael.json`: frame rectangles and timing information, includes combo order.
- `preview.html`: preview player with selectable actions; open through a local web server.
- `kael-preview.png`: enlarged checkerboard validation image, NOT a production atlas.
- `build_kael.py` and `kael_reference_sheet.png`: reproducible source conversion; requires pillow, numpy, opencv-python, scipy.

## Animation layout
| Row | Action | Frames |
|---:|---|---:|
|0|idle|8|
|1|walk|8|
|2|run|8|
|3|attack1 (horizontal slash)|8|
|4|attack2 (vertical slash)|8|
|5|attack3 (rotating slash)|8|
|6|skill1 (uses the dash frames)|6|
|7|skill2 (barehand lightning)|8|
|8|dash|6|
|9|hit|4|

No jump, death, or dodge animations. All frames are 64x64 and characters face the camera. Walk/run boots are explicitly redrawn with alternating positions, because the source has extremely subtle gait changes. The eighth frame for idle/walk/run is artistically reconstructed.

## Quick start (ES module)

```js
import { KAEL, decodeFrame, getFrame } from './kael-sprites.mjs';

let animation = 'run';
let elapsedMs = 650;
let frameIndex = getFrame(animation, elapsedMs);
let rgba = decodeFrame(animation, frameIndex); // Uint8ClampedArray(64*64*4)
```

For browser Canvas, import `frameToImageData`, call `ctx.putImageData` on an offscreen 64px canvas, and then `ctx.drawImage` with `ctx.imageSmoothingEnabled=false`. Alternatively load `assets/kael.png` and use `kael.json` rectangles with `drawImage`.

Preview with `python -m http.server 8000` from inside this directory and open `http://localhost:8000/preview.html`.

## Important limitations
The reference file is an AI-rendered **presentation mock-up**, not a true tiled source atlas. Some sword/VFX edges overlap UI borders. This converter reconstructs around those areas and preserves the original's recognizability, but it cannot recover information that was never present in the mock-up, nor guarantee pixel-identical character pixels, perfect animation flow, or clean separation of every translucent effect. Review all frames in-game and hand-retouch edges for production.
